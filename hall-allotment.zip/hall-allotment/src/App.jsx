import {useState} from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
const App = () => {
    const [action,setAction] = useState("Login");
    const [total,setTotal]=useState(12);
    const [completed, setCompleted] = useState(0);
    const [remaining, setRemaining] = useState(total);
    const [halls,setHalls]=useState(Array(12).fill(40));
    const [selected,setSelected]=useState([]);
    const data=[
      {Date: "05/11/2024", Slot: 'I', Time: "FN" },
      {Date: "05/11/2024", Slot: 'II', Time: "AN" },
      {Date: "06/11/2024", Slot: 'I', Time: "FN" },
      {Date: "06/11/2024", Slot: 'II', Time: "AN" },
      {Date: "07/11/2024", Slot: 'I', Time: "FN" },
      {Date: "07/11/2024", Slot: 'II', Time: "AN" },
      {Date: "08/11/2024", Slot: 'I', Time: "FN" },
      {Date: "08/11/2024", Slot: 'II', Time: "AN" },
      {Date: "09/11/2024", Slot: 'I', Time: "FN" },
      {Date: "09/11/2024", Slot: 'II', Time: "AN" },
      {Date: "10/11/2024", Slot: 'I', Time: "FN" },
      {Date: "10/11/2024", Slot: 'II', Time: "AN" },
    ];
    const TotalDuty = () => {
      if(document.getElementById('P').checked){
        setTotal(10);
        setRemaining(10-completed);
      }
      else{
        setTotal(12);
        setRemaining(12-completed);
      }
    };
    const handleRadioChange = () => {
      TotalDuty();
    };
    const handleClick = (event, newAction) => {
      event.preventDefault();
      setAction(newAction);
  };
  const Counter = (index)=>{
      if(halls[index]-1>-1 && completed<total){
        halls[index]-=1;
        setHalls([...halls]);
        setCompleted(count => count + 1);
        setRemaining(count => count - 1);
        setSelected(prevSelected=>[...prevSelected, data[index]]);
      }
  };
    return (
      <div className="bg-img">
    <div className='outer-box'>
    <h1>{action}</h1>
    <div className='box'>
    <form>
      <div className="inputs">
        {action==="Staff Registration"?
        <div>
          <div className="input-container">
  <i className="fas fa-user"></i>
  <input id="Name" className="InputIDs" type="text" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name"></input>
</div>
<div className="input-container">
  <span><i className="fas fa-building"></i></span>
  <input id="Dept" className="InputIDs" type="text" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Department"></input>
</div>
<label>Designation</label>
<div className="radio-group">
  <label>
    <input id="AP" type="radio" value="AP" name="desg" onChange={handleRadioChange} /> Assistant Professor
  </label>
  <label>
    <input id="P" type="radio" value="P" name="desg" onChange={handleRadioChange} /> Professor
  </label>
</div> 
<div className="input-container">
  <i className="fas fa-envelope"></i>
  <input id="mail" className="InputIDs" type="email" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email"></input>
</div>
<div className="input-container">
  <i className="fas fa-phone"></i>
  <input id="mobile" className="InputIDs" type="text" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mobile"></input>
</div>
<div className="input-container">
  <i className="fas fa-user"></i>
  <input id="StaffID" className="InputIDs" type="text" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Staff ID"></input>
</div>
<div className="input-container">
  <i className="fas fa-key"></i>
  <input id="Password" className="InputIDs" type="password" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password"></input>
</div>
          <button id="Register" onClick={(event) => handleClick(event, "Done")}>Register</button><br></br>
          <div>Go back to Login: <span onClick={(event) => handleClick(event, "Login")}>Login</span></div>
        </div>:
        <div></div>
        }  
      {action==="Login"?
      <div>
        <div className="input-container">
  <i className="fas fa-user"></i>
  <input id="StaffID" className="InputIDs" type="text" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Staff ID"></input>
</div>
<div className="input-container">
  <i className="fas fa-key"></i>
  <input id="Password" className="InputIDs" type="password" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password"></input>
</div>
        <button id="Login" onClick={(event) => handleClick(event, "Slot Registration")}>Login</button><br></br>
        <div>Not Registered yet? <span onClick={(event) => handleClick(event, "Staff Registration")}>Register</span></div>
      </div>: 
      <div></div>
      }
      {action==="Done"?
        <div>
        <div id="done">Registration Complete!</div>
        <div>Go back to Login: <span onClick={(event) => handleClick(event, "Login")}>Login</span></div>
        </div>:
        <div></div>
        }
        {action==="Slot Registration"?
        <div>
          <ul>
            <li>Your duties Total: {total} </li>
            <li>Completed: {completed} </li>
            <li>Remaining: {remaining}</li>
          </ul>
          <div>
            <table className="table table-success table-striped">
              <thead>
                <tr>
                <th>Date</th>
                <th>Slot</th>
                <th>Time</th>
                <th>No. of halls available</th>
                <th>Selection</th>
                </tr>
                </thead>
                <tbody>
              <tr>
                <td>{data[0].Date}</td>
                <td>{data[0].Slot}</td>
                <td>{data[0].Time}</td>
                <td>{halls[0]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(0);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[1].Date}</td>
                <td>{data[1].Slot}</td>
                <td>{data[1].Time}</td>
                <td>{halls[1]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(1);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[2].Date}</td>
                <td>{data[2].Slot}</td>
                <td>{data[2].Time}</td>
                <td>{halls[2]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(2);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[3].Date}</td>
                <td>{data[3].Slot}</td>
                <td>{data[3].Time}</td>
                <td>{halls[3]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(3);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[4].Date}</td>
                <td>{data[4].Slot}</td>
                <td>{data[4].Time}</td>
                <td>{halls[4]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(4);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[5].Date}</td>
                <td>{data[5].Slot}</td>
                <td>{data[5].Time}</td>
                <td>{halls[5]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(5);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[6].Date}</td>
                <td>{data[6].Slot}</td>
                <td>{data[6].Time}</td>
                <td>{halls[6]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(6);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[7].Date}</td>
                <td>{data[7].Slot}</td>
                <td>{data[7].Time}</td>
                <td>{halls[7]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(7);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[8].Date}</td>
                <td>{data[8].Slot}</td>
                <td>{data[8].Time}</td>
                <td>{halls[8]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(8);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[9].Date}</td>
                <td>{data[9].Slot}</td>
                <td>{data[9].Time}</td>
                <td>{halls[9]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(9);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[10].Date}</td>
                <td>{data[10].Slot}</td>
                <td>{data[10].Time}</td>
                <td>{halls[10]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(10);}}>Select</button></td>
              </tr>
              <tr>
              <td>{data[11].Date}</td>
                <td>{data[11].Slot}</td>
                <td>{data[11].Time}</td>
                <td>{halls[11]}</td>
                <td><button className="Select" onClick={(event)=>{event.preventDefault(); Counter(11);}}>Select</button></td>
              </tr>
              </tbody>
            </table>
            <button onClick={(event)=>handleClick(event,"Hall Allotment")}>View</button>
            </div>
        </div>:<div></div>
        }
        {action=="Hall Allotment"?
        <div>
          <table className="table table-success table-striped">
          <thead>
            <tr>
                <th>Date</th>
                <th>Slot</th>
                <th>Time</th>
                </tr>
              </thead>
              <tbody>
                {selected.map((row,index)=>(
                  <tr key={index}>
                    <td>{row.Date}</td>
                    <td>{row.Slot}</td>
                    <td>{row.Time}</td>
                  </tr>
                ))}
              </tbody>
              </table>
        </div>:
        <div></div>
        }
      </div>
    </form>
    </div>
    </div>
    </div>
  );
};
export default App;
